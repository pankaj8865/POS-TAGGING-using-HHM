import codecs
import os
import sys

# Global Variables definition
tags = ['C0', 'C1', 'C2', 'C3', 'C4', 'C5', 'C6', 'C7', 'C8', 'C9', 'C10', 'C11', 'C12', 'C13', 'C14', 'C15', 'C16', 'C17', 'C18', 'C19', 'C20', 'C21', 'C22', 'C23', 'C24', 'C25']

# Function: max_connect
	
#	max_connect function performs the viterbi decoding. Choosing which tag
#	for the current word leads to a better tag sequence. 

def max_connect(x, y, viterbi_matrix, emission, transmission_matrix):
	max = -99999
	path = -1
	
	for k in xrange(len(tags)):
		val = viterbi_matrix[k][x-1] * transmission_matrix[k][y]
		if val * emission > max:
			max = val
			path = k
	return max, path


# Function: main
	
#	1) Unique words are extracted from the training data.
#	2) Count of occurence of each tag is calculated.
#	3) Emission & Transmission matrix are initialized and computed.
#	4) Testing data is read.
#	5) Trellis for viterbi decoding is computed.
#	6) Path is printed on to output file.

def main(language, test_file_path):

	exclude = ["<s>", "</s>", "START", "END"]

	filepath = ["./data/hindi_training_unsupervised.txt"]
	languages = ["hindi"]
	f = codecs.open(filepath[language], 'r', encoding='utf-8')
	file_contents = f.readlines()

	wordtypes = []
	tagscount = []

	for x in xrange(len(tags)):
		tagscount.append(0)

	for x in xrange(len(file_contents)):
		line = file_contents.pop(0).strip().split(' ')
		for i, word in enumerate(line):
			if i == 0:
				if word not in wordtypes and word not in exclude:
					wordtypes.append(word)
			else:
				if word in tags and word not in exclude:
					tagscount[tags.index(word)] += 1
	f.close()
		
	emission_matrix = []
	transmission_matrix = []
			
	for x in xrange(len(tags)):
		emission_matrix.append([])
		for y in xrange(len(wordtypes)):
			emission_matrix[x].append(0)

	for x in xrange(len(tags)):
		transmission_matrix.append([])
		for y in xrange(len(tags)):
			transmission_matrix[x].append(0)


	f = codecs.open(filepath[language], 'r', encoding='utf-8')
	file_contents = f.readlines()

	row_id = -1
	for x in xrange(len(file_contents)):
		line = file_contents.pop(0).strip().split(' ')

		if line[0] not in exclude and len(line) >= 2:
			col_id = wordtypes.index(line[0])
			prev_row_id = row_id
			row_id = tags.index(line[1])
			emission_matrix[row_id][col_id] += 1
			if prev_row_id != -1:
				transmission_matrix[prev_row_id][row_id] += 1
		else:
			row_id = -1
					
	for x in xrange(len(tags)):
		for y in xrange(len(wordtypes)):
			if tagscount[x] != 0:
				emission_matrix[x][y] = float(emission_matrix[x][y]) / tagscount[x]

	for x in xrange(len(tags)):
		for y in xrange(len(tags)):
			if tagscount[x] != 0:
				transmission_matrix[x][y] = float(transmission_matrix[x][y]) / tagscount[x]

	testpath = test_file_path
	file_test = codecs.open(testpath, 'r', encoding='utf-8')

	test_input = file_test.readlines()
	test_words = []
	pos_tags = []

	file_output = codecs.open("./output/"+ languages[int(sys.argv[1])] +"_tags_unsupervised.txt", 'w', 'utf-8')
	file_output.close()

	for j in xrange(len(test_input)):
		
		test_words = []
		pos_tags = []

		line = test_input.pop(0).strip().split(' ')
		
		for word in line:
			test_words.append(word)
			pos_tags.append(-1)

		viterbi_matrix = []
		viterbi_path = []
		
		for x in xrange(len(tags)):
			viterbi_matrix.append([])
			viterbi_path.append([])
			for y in xrange(len(test_words)):
				viterbi_matrix[x].append(0)
				viterbi_path[x].append(0)

		for x in xrange(len(test_words)):
			for y in xrange(len(tags)):
				if test_words[x] in wordtypes:
					word_index = wordtypes.index(test_words[x])
					tag_index = tags.index(tags[y])
					emission = emission_matrix[tag_index][word_index]
				else:
					emission = 0.001

				if x > 0:
					max, viterbi_path[y][x] = max_connect(x, y, viterbi_matrix, emission, transmission_matrix)
				else:
					max = 1
				viterbi_matrix[y][x] = emission * max

		maxval = -999999
		maxs = -1
		for x in xrange(len(tags)):
			if viterbi_matrix[x][len(test_words)-1] > maxval:
				maxval = viterbi_matrix[x][len(test_words)-1]
				maxs = x
			
		for x in range(len(test_words)-1, -1, -1):
			pos_tags[x] = maxs
			maxs = viterbi_path[maxs][x]

		# print pos_tags
			
		file_output = codecs.open("./output/"+ languages[int(sys.argv[1])] +"_tags_unsupervised.txt", 'a', 'utf-8')
		for i, x in enumerate(pos_tags):
			file_output.write(test_words[i] + "_" + tags[x] + " ")
		file_output.write(" ._.\n")

	f.close()
	file_output.close()
	file_test.close()

	print "Kindly check ./output/" + languages[int(sys.argv[1])] + "_tags_unsupervised.txt file for POS tags."
